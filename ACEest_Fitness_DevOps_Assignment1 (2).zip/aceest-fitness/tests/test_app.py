import pytest
from app import app, members

@pytest.fixture()
def client():
    app.config.update(TESTING=True)
    members.clear()
    with app.test_client() as test_client:
        yield test_client
    members.clear()

def test_home_returns_welcome_message(client):
    response = client.get("/")
    assert response.status_code == 200
    assert response.get_json()["message"] == "Welcome to ACEest Fitness & Gym"

def test_health_endpoint(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.get_json()["status"] == "healthy"

def test_get_members_returns_empty_list(client):
    response = client.get("/members")
    assert response.status_code == 200
    assert response.get_json() == []

def test_add_member_success(client):
    response = client.post("/members", json={"name": "John", "age": 25, "membership": "Premium"})
    assert response.status_code == 201
    assert response.get_json()["name"] == "John"
    assert response.get_json()["membership"] == "Premium"

def test_add_member_requires_name(client):
    response = client.post("/members", json={"age": 25})
    assert response.status_code == 400
    assert response.get_json()["error"] == "Name is required"

def test_get_existing_member(client):
    client.post("/members", json={"name": "John"})
    response = client.get("/members/1")
    assert response.status_code == 200
    assert response.get_json()["name"] == "John"

def test_missing_member_returns_404(client):
    response = client.get("/members/999")
    assert response.status_code == 404
    assert response.get_json()["error"] == "Member not found"

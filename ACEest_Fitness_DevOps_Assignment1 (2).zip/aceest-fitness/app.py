from flask import Flask, jsonify, request

app = Flask(__name__)
members = []  # In-memory demo storage; records reset when the app restarts.

@app.route("/", methods=["GET"])
def home():
    return jsonify({"message": "Welcome to ACEest Fitness & Gym"}), 200

@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "healthy"}), 200

@app.route("/members", methods=["GET"])
def get_members():
    return jsonify(members), 200

@app.route("/members", methods=["POST"])
def add_member():
    data = request.get_json(silent=True)
    if not data or not isinstance(data, dict) or not str(data.get("name", "")).strip():
        return jsonify({"error": "Name is required"}), 400
    member = {
        "id": len(members) + 1,
        "name": str(data["name"]).strip(),
        "age": data.get("age"),
        "membership": data.get("membership", "Basic"),
    }
    members.append(member)
    return jsonify(member), 201

@app.route("/members/<int:member_id>", methods=["GET"])
def get_member(member_id):
    for member in members:
        if member["id"] == member_id:
            return jsonify(member), 200
    return jsonify({"error": "Member not found"}), 404

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)

# ACEest Fitness & Gym — DevOps Assignment 1

## Project overview
A small Flask-based gym member management API demonstrating Git/GitHub, Pytest, Docker, Jenkins, and GitHub Actions CI.

## Features
- `GET /` — welcome message
- `GET /health` — health check
- `GET /members` — list members
- `POST /members` — add a member
- `GET /members/<member_id>` — retrieve a member
- Validation when a member name is missing

**Demo limitation:** records are stored in memory and reset when the app restarts. This is a learning example, not a production database.

## Technology stack
Python 3.11, Flask, Pytest, Git, GitHub, Docker, Jenkins, GitHub Actions.

## Project structure
```text
aceest-fitness/
├── .github/workflows/main.yml
├── tests/test_app.py
├── .dockerignore
├── .gitignore
├── app.py
├── Dockerfile
├── Jenkinsfile
├── README.md
└── requirements.txt
```

## Local setup
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python app.py
```
Open `http://localhost:5000/`. Stop the server with `Ctrl+C`.

## Run tests
```bash
pytest -v
```
Tests cover the home endpoint, health check, listing members, adding a member, missing-name validation, retrieving a member, and a not-found response.

## Test the API manually
```bash
curl http://localhost:5000/members
curl -X POST http://localhost:5000/members -H "Content-Type: application/json" -d '{"name":"Anu","age":24,"membership":"Premium"}'
curl http://localhost:5000/members/1
```

## Docker
```bash
docker build -t aceest-fitness .
docker run --rm -p 5000:5000 --name aceest-app aceest-fitness
```
In another terminal, run `curl http://localhost:5000/`. To run tests inside the image:
```bash
docker run --rm --entrypoint pytest aceest-fitness -v
```

## Jenkins integration
The `Jenkinsfile` defines source checkout, dependency installation, syntax validation, unit tests, Docker image build, and tests inside the container. In Jenkins, create a Pipeline job connected to this GitHub repository, choose **Pipeline script from SCM**, select Git and branch `*/main`. The Jenkins agent needs Python 3, Git, Docker, and permission to run Docker commands. If the instructor requires a Freestyle job, use these commands in “Execute shell” build steps instead.

## GitHub Actions CI
`.github/workflows/main.yml` runs on pushes to `main` and pull requests targeting `main`. It installs dependencies, checks Python syntax, runs Pytest, builds a Docker image, and runs Pytest inside the image. Check the GitHub **Actions** tab for a successful workflow run.

## GitHub submission
Create an empty **public** GitHub repository named `aceest-fitness`, then run:
```bash
git init
git add .
git commit -m "Add Flask fitness application and tests"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/aceest-fitness.git
git push -u origin main
```
Replace `YOUR_USERNAME` with your actual GitHub username. For later changes:
```bash
git add .
git commit -m "Describe the change"
git push
```

## Evidence to capture
1. Project files visible in the GitHub repository.
2. `pytest -v` showing all tests pass.
3. Successful Docker image build.
4. Running container and application response.
5. GitHub Actions workflow with a green success status.
6. Jenkins successful build.

## Conclusion
This project demonstrates a basic workflow from source control through syntax validation, unit testing, containerization, and CI pipeline execution.
